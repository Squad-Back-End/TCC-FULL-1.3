import React from 'react';
  
const PageNotFound = () =>{
    return (
    <div>
        <h1>Erro 404</h1>
        <h1>Pagina não encontrada</h1>
    </div>
    );
}
  
export default PageNotFound;